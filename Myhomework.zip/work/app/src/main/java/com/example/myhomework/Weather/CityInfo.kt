package com.example.homework10.Weather

data class CityInfo(
    val city: String,
    val citykey: String,
    val parent: String,
    val updateTime: String
)